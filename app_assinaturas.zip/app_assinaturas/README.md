# app_assinaturas
Aplicativo de Gerenciamento de Assinaturas para acompanhar seus serviços online. Adicione, edite e visualize suas assinaturas em um só lugar. Mantenha o controle de seus gastos e próximos vencimentos. Ideal para quem busca organização e economia.
